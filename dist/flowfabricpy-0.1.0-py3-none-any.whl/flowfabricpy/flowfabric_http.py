# flowfabric_http.py
"""
Functions for GET and POST requests using the flowfabric API
"""
import requests
from .auth import flowfabric_get_token

# GET request
def flowfabric_get(endpoint, token=None, verbose=False):
    """
    HTTP GET request using the flowfabric API

    :param endpoint: The endpoint for the GET request
    :type endpoint: str

    :param token: (Optional) JWT bearer token
    :type token: str or None

    :param verbose: (Optional) Provides extra information for debugging
    :type verbose: bool or None

    :return: A response object containing information from the specified endpoint
    """
    base_url = "https://flowfabric-api.lynker-spatial.com"
    if token is None:
        # get a token
        token = flowfabric_get_token()['id_token']
        print("No token provided, using token from flowfabric_get_token()") if verbose else None
    try:
        headers = {
            "Authorization": f"Bearer {token.strip()}"
        }
        url = "".join([base_url, endpoint])
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return response
    except requests.exceptions.Timeout:
        return {"Error": "Request timed out"}
    except requests.exceptions.RequestException as e:
        return{"Error": str(e)}

# POST request
def flowfabric_post(endpoint, body, token=None, verbose=False):
    """
    HTTP POST request using the flowfabric API

    :param endpoint: The endpoint for the POST request
    :type endpoint: str

    :param body: The body of the POST request
    :type body: dict

    :param token: (Optional) JWT bearer token
    :type token: str or None

    :param verbose: (Optional) Provides extra information for debugging
    :type verbose: bool or None

    :return: A response object containing information from the specified endpoint
    """
    base_url = "https://flowfabric-api.lynker-spatial.com"
    if token is None:
        # get a token
        token = flowfabric_get_token()['id_token']
        print("No token provided, using token from flowfabric_get_token()") if verbose else None
    try:
        headers = {
            "Authorization": f"Bearer {token.strip()}"
        }
        url = "".join([base_url, endpoint])
        response = requests.post(url, json=body, headers=headers, timeout=10)
        return response
    except requests.exceptions.Timeout:
        return{"Error": "Request timed out"}
    except requests.exceptions.RequestException as e:
        return{"Error": str(e)}
